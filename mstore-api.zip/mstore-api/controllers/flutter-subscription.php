<?php
require_once(__DIR__ . '/flutter-base.php');
if (defined('WC_ABSPATH')) {
    // WC 3.6+ - Cart and other frontend functions are not included for REST requests.
    include_once WC_ABSPATH . 'includes/wc-cart-functions.php';
    include_once WC_ABSPATH . 'includes/wc-notice-functions.php';
    include_once WC_ABSPATH . 'includes/wc-template-hooks.php';
    include_once WC_ABSPATH . 'includes/legacy/api/v3/class-wc-api-resource.php';
    include_once WC_ABSPATH . 'includes/legacy/api/v3/class-wc-api-orders.php';
    include_once WC_ABSPATH . 'includes/legacy/api/v3/class-wc-api-exception.php';
}
if (defined('ABSPATH')) {
    if(file_exists(ABSPATH . 'wp-content/plugins/woocommerce-subscriptions/woocommerce-subscriptions.php')){
        include_once ABSPATH . 'wp-content/plugins/woocommerce-subscriptions/woocommerce-subscriptions.php';
    }else{
        return;
    }
}

class CUSTOM_WC_API_Subscriptions extends  WC_API_Subscriptions
{

    /**
     * Endpoint namespace
     *
     * @var string
     */
    protected $namespace = 'api/flutter_subscription';

    /**
     * Register all routes releated with stores
     *
     * @return void
     */
    public function __construct()
    {
        add_action('rest_api_init', array($this, 'register_flutter_subscriptions_routes'));
        add_filter( 'user_has_cap', [ $this, 'set_user_cap' ], 25, 3 );
    }

    public function register_flutter_subscriptions_routes()
    {
        register_rest_route($this->namespace, '/create', array(
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array($this, 'create_subscription_order'),
                'permission_callback' => array($this, 'custom_create_item_permissions_check'),
            ),
        ));
    }

    function custom_create_item_permissions_check($request)
    {
        return true;
    }

    /**
     * Checks if a user has a certain capability
     *
     * @access public
     * @param array $allcaps
     * @param array $caps
     * @param array $args
     * @return array
     */
    function set_user_cap( $allcaps, $caps, $args ) {
        $allcaps['publish_shop_orders'] = true;
        return $allcaps;
    }

    function create_subscription_order($request)
    {
        $json = file_get_contents('php://input');
        $body = json_decode($json, TRUE);
        if(isset($body['subscription']['customer_id'])){
            wp_set_current_user($body['subscription']['customer_id']);
        }
        return  $this->create_subscription($body);
    }
}

new CUSTOM_WC_API_Subscriptions();